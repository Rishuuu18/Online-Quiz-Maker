import React from "react";

export default function Analytics() {
  return <h2>Quiz Analytics</h2>;
}
