import React from "react";

export default function AttemptQuiz() {
  return <h2>Attempt a Quiz</h2>;
}
