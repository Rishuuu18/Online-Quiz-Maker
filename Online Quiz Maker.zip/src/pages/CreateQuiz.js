import React from "react";

export default function CreateQuiz() {
  return <h2>Create a New Quiz</h2>;
}
