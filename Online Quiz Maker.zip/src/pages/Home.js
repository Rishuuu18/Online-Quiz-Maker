import React from "react";

export default function Home() {
  return (
    <div>
      <h1>Welcome to the Quiz Platform</h1>
      <p>Create and attempt quizzes with analytics and leaderboard tracking.</p>
    </div>
  );
}
