import React from "react";

export default function Leaderboard() {
  return <h2>Leaderboard</h2>;
}
